SECRET_KEY = '_'

INSTALLED_APPS = (
    'django.contrib.staticfiles',
    'tests.with_django.test_app',
)

TEST_OVERRIDES = {
    'FOO': 'BAR'
}