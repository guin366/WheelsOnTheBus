version_info = (1, 0, 7)
__version__ = '.'.join(map(str, version_info[:3])) + ''.join(map(str, version_info[3:]))
