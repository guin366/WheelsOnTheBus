#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "6d4cce1f8e"     # abbreviated commit hash
commit = "6d4cce1f8eb80c0bf49d35876d28daa55a05800f"  # commit hash
date = "2020-01-09 19:03:38 +0100"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "tag: v3.6, master"  # incl. current branch
commit_message = """Release 3.6.
"""
