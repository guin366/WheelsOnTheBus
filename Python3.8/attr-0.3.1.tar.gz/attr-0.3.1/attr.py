# New popular attrs.org used by pytest.org defines another "attr" package that shadows this "attr" module.
# Please use "dry_attr" alias to unshadow it:
from dry_attr import *
