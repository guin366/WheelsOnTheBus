import warnings
warnings.warn("qtconsole.ipython_widget is deprecated; "
              "use qtconsole.jupyter_widget", DeprecationWarning)
from .jupyter_widget import *
