from .decorators import jitclass
from . import boxing  # Has import-time side effect
