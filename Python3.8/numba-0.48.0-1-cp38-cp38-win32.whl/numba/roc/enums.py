from __future__ import print_function, absolute_import, division

CLK_LOCAL_MEM_FENCE = 0
CLK_GLOBAL_MEM_FENCE = 1
