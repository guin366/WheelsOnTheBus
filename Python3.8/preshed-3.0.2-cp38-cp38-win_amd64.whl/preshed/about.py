__title__ = "preshed"
__version__ = "3.0.2"
__summary__ = "Cython hash table that trusts the keys are pre-hashed"
__uri__ = "https://github.com/explosion/preshed"
__author__ = "Matthew Honnibal"
__email__ = "matt@explosion.ai"
__license__ = "MIT"
__release__ = True
