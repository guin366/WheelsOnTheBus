# flake8: noqa
from .base import (
    ASSETS,
    APP_ROOT
)
