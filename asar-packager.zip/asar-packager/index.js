const asar = require('asar');
const fs = require('fs');

const savePath = "./dist/";
fs.existsSync(savePath) || fs.mkdirSync(savePath);

const src = '';
const dest = 'app.asar';

await asar.createPackage(src, dest);
console.log(`created package src=${src}, dest=${dest}`);