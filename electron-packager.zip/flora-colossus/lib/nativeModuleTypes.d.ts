export declare enum NativeModuleType {
    NONE = 0,
    NODE_GYP = 1,
    PREBUILD = 2
}
