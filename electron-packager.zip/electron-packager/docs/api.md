[API Documentation](https://electron.github.io/electron-packager/) has moved.
