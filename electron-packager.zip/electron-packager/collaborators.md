## Collaborators

Electron Packager is only possible due to the excellent work of the following collaborators:

* [malept](https://github.com/malept) (current primary maintainer)
* [maxogden](https://github.com/maxogden) (Creator & maintainer emeritus)

and many others as shown in the [GitHub contributors graph](https://github.com/electron/electron-packager/graphs/contributors).
