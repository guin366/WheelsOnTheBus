const sqlite3 = require('better-sqlite3');

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
let db = new sqlite3('./test.db', sqlite3.OPEN_READWRITE, (err)=>{
  if (err){
    return console.error(err.message);
  }

  console.log('Connected to SQLite database.');
});

function JSONtoNewDB(json, filename){
  let newdb = new sqlite3('./' + filename + '.db', sqlite3.OPEN_READWRITE, (err)=>{
    if (err){
      console.error(err.message);
      return null;
    }
  })
  if (newdb == null) return;

  //initialize table
  var keys = []
  for (const row of json){
    for (const [key, entry] of Object.entries(row)){
      if (!keys.includes(key)){
        keys.push(key);
      }
    }
  }
  newdb.prepare("DROP TABLE IF EXISTS " + filename).run();
  var sql = 'CREATE TABLE ' + filename + ' (';
  for (const key of keys){
    sql = sql + key + " TEXT DEFAULT \" \",";
  }
  sql = sql.slice(0,-1);
  sql = sql + ")"
  newdb.prepare(sql).run();

  //add data
  for (const row of json){
    var sql = "INSERT INTO " + filename + " (";
    for (const [key, entry] of Object.entries(row)){
      sql = sql + key + ",";
    }
    sql = sql.slice(0,-1);
    sql = sql + ") VALUES(";
    for (const [key, entry] of Object.entries(row)){
      sql = sql + "\'" + entry + "\'" + ",";
    }
    sql = sql.slice(0,-1);
    sql = sql + ")"
    console.log(sql);
    newdb.prepare(sql).run();
  }
}

function GetAllRows(fileName, tableName){
  let newdb = new sqlite3('./' + fileName + '.db', sqlite3.OPEN_READWRITE, (err)=>{
    if (err){
      console.error(err.message);
      return null;
    }
  })
  if (newdb == null) return;

  var statement = newdb.prepare('SELECT * FROM ' + tableName);
  console.log(statement.all());
}

var testjson = [
  {
    "name": "steven",
    "birthday": "12/12/12",
    "height": "5.8"
  },
  {
    "name" : "fred",
    "birthday": "11/11/11",
    "height": "1.4",
    "weight": "10"
  }
];

JSONtoNewDB(testjson, "test1");
GetAllRows("test1", "test1");

db.close((err) => {
  if (err){
    return console.error(err.message);
  }
  console.log('Close the database connection.');
});