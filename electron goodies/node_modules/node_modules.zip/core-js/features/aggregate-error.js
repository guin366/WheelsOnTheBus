require('../modules/web.dom-collections.iterator');
require('../modules/es.string.iterator');
require('../modules/esnext.aggregate-error');
var path = require('../internals/path');

module.exports = path.AggregateError;
