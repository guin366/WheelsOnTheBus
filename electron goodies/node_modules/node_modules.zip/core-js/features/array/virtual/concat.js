var parent = require('../../../es/array/virtual/concat');

module.exports = parent;
