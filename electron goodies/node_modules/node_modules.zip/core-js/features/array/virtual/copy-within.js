var parent = require('../../../es/array/virtual/copy-within');

module.exports = parent;
