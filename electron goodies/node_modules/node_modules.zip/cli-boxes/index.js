'use strict';
const cliBoxes = require('./boxes.json');

module.exports = cliBoxes;
// TODO: Remove this for the next major release
module.exports.default = cliBoxes;
