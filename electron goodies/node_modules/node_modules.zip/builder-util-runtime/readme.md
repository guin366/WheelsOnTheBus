# builder-util-runtime

HTTP utilities. Used by [electron-builder](https://github.com/electron-userland/electron-builder).